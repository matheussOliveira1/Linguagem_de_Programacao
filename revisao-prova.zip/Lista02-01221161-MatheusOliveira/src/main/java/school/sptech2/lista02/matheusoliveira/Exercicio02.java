/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package school.sptech2.lista02.matheusoliveira;

import java.util.Scanner;

/**
 *
 * @author Aluno
 */
public class Exercicio02 {
    
    public static void main(String[] args) {
        //Numeros Impares
        
        for (int i = 0; i <= 90; i++) {
            if(i % 2 == 1){
                System.out.println(i);
            }
        }
    }
}
