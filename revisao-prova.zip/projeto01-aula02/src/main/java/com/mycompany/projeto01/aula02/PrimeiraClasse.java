/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projeto01.aula02;

/**
 *
 * @author Aluno
 */
public class PrimeiraClasse {
    //Para ser possível a execução de uma Classe
    
    /*
    Sempre utilizaremos o:
    */
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}
